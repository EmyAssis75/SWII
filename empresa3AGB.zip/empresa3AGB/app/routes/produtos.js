module.exports = function(app){
    app.get('/produtos', function(request, response){
        var mysql = require('mysql');
        var connection = mysql.createConnection({
            host: 'localhost',
            database: 'livraria',
            user: 'root',
            password: ''
        });

        connection.query('select * from produtos', function(err, results){
            response.render('produtos/lista.ejs', {lista:results});
            connection.end();
        });


    });
}