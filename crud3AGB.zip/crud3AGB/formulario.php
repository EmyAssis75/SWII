<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="POST" action="cadastro.php">
        <label>Nome:</label>
        <input type="text" name="nome" placeholder="Digite seu nome" />
        <br>
        <label>Telefone:</label>
        <input type="text" name="telefone" placeholder="Digite seu telefone" />
        <br>
        <label>E-mail:</label>
        <input type="text" name="email" placeholder="Digite seu email" />
        <br>
        <input type="submit" name="botao" value="Enviar" />
        <input type="submit" name="botao" value="Exibir" />
    </form>
</body>

</html>